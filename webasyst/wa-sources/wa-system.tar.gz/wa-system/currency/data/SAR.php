<?php

return array(
    'code' => 'SAR',
    'sign' => 'SR',
	'iso4217' => '682',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Saudi riyal',
    'name' => array(
        array('riyal', 'riyals'),
    ),
    'frac_name' => array(
        array('halala', 'halalas'),
    )
);