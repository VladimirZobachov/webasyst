<?php

return array(
    'code' => 'SEK',
    'sign' => 'kr',
	'iso4217' => '752',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Swedish krona',
    'name' => array(
        array('krona', 'kronor'),
    ),
    'frac_name' => array(
        'ore',
    )
);