<?php

return array(
    'code' => 'CLP',
    'sign' => '$',
	'iso4217' => '152',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Chilean peso',
    'name' => array(
        array('peso', 'pesos'),
    ),
    'frac_name' => array(
        array('centavo', 'centavos'),
    )
);