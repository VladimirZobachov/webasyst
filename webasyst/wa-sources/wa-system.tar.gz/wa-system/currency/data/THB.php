<?php

return array(
    'code' => 'THB',
    'sign' => '฿',
	'iso4217' => '764',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Thai baht',
    'name' => array(
        array('baht', 'bahts'),
    ),
    'frac_name' => array(
        array('satang', 'satangs'),
    )
);