<?php

return array(
    'code' => 'PKR',
    'sign' => 'Rs',
	'iso4217' => '586',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Pakistani rupee',
    'name' => array(
        array('rupee', 'rupees'),
        '₨',
    ),
    'frac_name' => array(
    )
);