<?php
return array(
    'app.installer'=>array(
        'version' => 'latest', // 3.0.0
        'strict'  => true,
    ),
);