<?php

class teamEventExternalParamsModel extends teamParamsModel
{
    protected $relation_id = 'event_external_id';
    protected $table = 'team_event_external_params';
}
